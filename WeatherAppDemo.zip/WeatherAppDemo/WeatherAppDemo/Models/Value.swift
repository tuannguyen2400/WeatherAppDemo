struct Value: Decodable, Equatable {
    let value: String
}
