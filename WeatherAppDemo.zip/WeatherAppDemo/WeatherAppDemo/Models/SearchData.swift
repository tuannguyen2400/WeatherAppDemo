struct SearchData: Decodable, Equatable {
    let data: Data

    enum CodingKeys: String, CodingKey {
        case data = "search_api"
    }
}

extension SearchData {
    struct Data: Decodable, Equatable {
        let result: [Result]
    }
}

extension SearchData {
    struct Result: Decodable, Equatable {
        let areaName: [Value]
        let country: [Value]
        let region: [Value]
    }
}
