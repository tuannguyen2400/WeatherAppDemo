import UIKit

class CityViewController: UIViewController {
    static func create(city: String) -> CityViewController {
        let storyboard = UIStoryboard(name: "City", bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier: "CityViewController") as! CityViewController
        viewController.viewModel = CityViewModel(city: city)
        return viewController
    }

    @IBOutlet weak var weatherIconImageView: UIImageView!
    @IBOutlet weak var humidityLabel: UILabel!
    @IBOutlet weak var weatherDescriptionLabel: UILabel!
    @IBOutlet weak var temperatureLabel: UILabel!

    private var viewModel: CityViewModel!

    override func viewDidLoad() {
        super.viewDidLoad()
        setupView()
        setupBinding()
        viewModel.fetchWeather()
    }
}

private extension CityViewController {
    func setupView() {
        setUpNavigationBar()
        setupWeatherIconImageView()
        setupLabel(humidityLabel)
        setupLabel(weatherDescriptionLabel)
        setupLabel(temperatureLabel)
    }

    func setUpNavigationBar() {
        title = viewModel.city
    }

    func setupBinding() {
        viewModel.reloadImageData = { [weak self] data in
            DispatchQueue.main.async {
                self?.weatherIconImageView.image = UIImage(data: data)
            }
        }

        viewModel.reloadData = { [weak self] data in
            DispatchQueue.main.async {
                self?.humidityLabel.text = data.humidity
                self?.weatherDescriptionLabel.text = data.description
                self?.temperatureLabel.text = data.temperature
            }
        }
    }

    func setupWeatherIconImageView() {
        weatherIconImageView.contentMode = .scaleAspectFit
    }

    func setupLabel(_ label: UILabel) {
        label.font = .systemFont(ofSize: 18, weight: .medium)
        label.textColor = .darkText
        label.textAlignment = .left
        label.numberOfLines = 0
    }
}
